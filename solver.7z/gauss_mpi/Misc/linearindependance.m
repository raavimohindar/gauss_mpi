clear all;

close all;

%p = p0 + (p1 - p0) * s + (p2 - p0) * t

vert1     = [-0.001 0 0.01388888888885929];
vert2     = [0.001 0 0.0138888888889196];
vert3     = [-5.421010862427522e-20 0 0.01250000000000067];

%centroid  = (vert1 + vert2 + vert3)/3.0;

centroid  = vert1 + ((vert2-vert1)*0.4) + ((vert3-vert1)*0.5)

edge1     = vert3 - vert2;
edge2     = vert3 - vert1;
edge3     = vert2 - vert1;

n         = cross(edge1,edge2); 
area      = norm(n) / 2;

rho1      = centroid - vert1;
rho2      = centroid - vert2;
rho3      = centroid - vert3;

f1        = (norm(edge1) / 2*area) * rho1;
f2        = (norm(edge2) / 2*area) * rho2;
f3        = (norm(edge3) / 2*area) * rho3;

vector1   = norm(edge2)*f1 - norm(edge1)*f2
vector2   = norm(edge3)*f1 - norm(edge1)*f3
