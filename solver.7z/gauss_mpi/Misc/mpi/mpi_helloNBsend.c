/******************************************************************************
* FILE: mpi_helloNBsend.c
* DESCRIPTION:
*   MPI tutorial example code: Simple hello world program that uses nonblocking
*   send/receive routines.
* AUTHOR: Blaise Barney
* LAST REVISED: 06/08/15
******************************************************************************/
#include "mpi.h"

#include <stdio.h>
#include <stdlib.h>

#define  MASTER		0

int main (int argc, char *argv[])
{

int  numtasks, taskid, len;

char hostname[MPI_MAX_PROCESSOR_NAME];

int  partner;

char message[17];
char custom_message[17];

MPI_Status stats[2];
MPI_Request reqs[2];

MPI_Init(&argc, &argv);

MPI_Comm_rank(MPI_COMM_WORLD,&taskid);
MPI_Comm_size(MPI_COMM_WORLD, &numtasks);

if (numtasks % 2 != 0) 
{
   if (taskid == MASTER)
      printf("Quitting. Need an even number of tasks: numtasks=%d\n", numtasks);

   return 0;
}

if (taskid == MASTER)
   printf("MASTER: Number of MPI tasks is: %d\n",numtasks);

sprintf(custom_message, "%s%d", "Hello_from_task_", taskid);

MPI_Get_processor_name(hostname, &len);

printf ("Hello from task %d on %s!\n", taskid, hostname);

partner = (taskid < numtasks/2) ? numtasks/2 + taskid : taskid - numtasks/2;
   
MPI_Irecv(&message,        strlen(custom_message)+1, MPI_CHAR, partner, 1, MPI_COMM_WORLD, &reqs[0]);

MPI_Isend(&custom_message, strlen(custom_message)+1, MPI_CHAR, partner, 1, MPI_COMM_WORLD, &reqs[1]);

MPI_Waitall(2, reqs, stats); /* now block until requests are complete */

printf("Task %d is partner with %s\n\n",taskid, message);

MPI_Finalize();

}