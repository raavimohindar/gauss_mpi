/******************************************************************************
* FILE: ser_mm.c
* DESCRIPTION:  
*   Serial Matrix Multiply - C Version
* AUTHOR: Blaise Barney
* LAST REVISED: 04/12/05
******************************************************************************/
#include <stdio.h>
#include <stdlib.h>

#define NRA 62 			/* number of rows in matrix A */
#define NCA 15			/* number of columns in matrix A */
#define NCB 7   		/* number of columns in matrix B */

int main(int argc, char *argv[])
{
int    i, j, k;			/* misc */
double a[ROWS_A][COLS_A], 		/* matrix A to be multiplied */
       b[COLS_A][COL_B],      	/* matrix B to be multiplied */
       c[ROWS_A][COL_B];		/* result matrix C */

printf("Starting serial matrix multiple example...\n");
printf("Using matrix sizes a[%d][%d], b[%d][%d], c[%d][%d]\n",
        ROWS_A,COLS_A,COLS_A,COL_B,ROWS_A,COL_B);

/* Initialize A, B, and C matrices */
printf("Initializing matrices...\n");
for (i=0; i<ROWS_A; i++)
   for (j=0; j<COLS_A; j++)
      a[i][j]= i+j;
for (i=0; i<COLS_A; i++)
   for (j=0; j<COL_B; j++)
      b[i][j]= i*j;
for(i=0;i<ROWS_A;i++)
   for(j=0;j<COL_B;j++)
      c[i][j] = 0.0;

/* Perform matrix multiply */
printf("Performing matrix multiply...\n");
for(i=0;i<ROWS_A;i++)
   for(j=0;j<COL_B;j++)
      for(k=0;k<COLS_A;k++)
         c[i][j]+= a[i][k] * b[k][j];

printf("Here is the result matrix:");
for (i=0; i<ROWS_A; i++) { 
   printf("\n"); 
   for (j=0; j<COL_B; j++) 
      printf("%6.2f   ", c[i][j]);
   }
printf ("\nDone.\n");
}
