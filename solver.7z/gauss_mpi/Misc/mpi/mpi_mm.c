/******************************************************************************
* FILE: mpi_mm.c
* DESCRIPTION:  
*   MPI Matrix Multiply - C Version
*   In this code, the master task distributes a matrix multiply 
*   operation to numtasks-1 worker tasks.
*   NOTE:  C and Fortran versions of this code differ because of the way
*   arrays are stored/passed.  C arrays are row-major order but Fortran
*   arrays are column-major order.
* AUTHOR: Blaise Barney. Adapted from Ros Leibensperger, Cornell Theory
*   Center. Converted to MPI: George L. Gusciora, MHPCC (1/95)
* LAST REVISED: 04/13/05
******************************************************************************/
#include "mpi.h"
#include <stdio.h>
#include <stdlib.h>

#define ROWS_A 100
#define COLS_A 100
#define COLS_B 50

#define MASTER 0

#define FROM_MASTER 1
#define FROM_WORKER 2

int main (int argc, char *argv[])
{
int numtasks,              /* number of tasks in partition */
	 taskid,                /* a task identifier */
	 numworkers,            /* number of worker tasks */
	 source,                /* task id of message source */
	 dest,                  /* task id of message destination */
	 mtype,                 /* message type */
	 rows,                  /* rows of matrix A sent to each worker */
	 chunksize, leftover, offset, /* used to determine rows sent to each worker */
	 i, j, k, rc;           /* misc */

double a[ROWS_A][COLS_A],
	    b[COLS_A][COLS_B],
	    c[ROWS_A][COLS_B];

MPI_Status status;

MPI_Init(&argc, &argv);

MPI_Comm_rank(MPI_COMM_WORLD, &taskid);
MPI_Comm_size(MPI_COMM_WORLD, &numtasks);

if (numtasks < 2 ) 
{
  printf("Need at least two MPI tasks. Quitting...\n");
  MPI_Abort(MPI_COMM_WORLD, rc);
  exit(1);
}

numworkers = numtasks-1;

   if (taskid == MASTER)
   {
      printf("mpi_mm has started with %d tasks.\n",numtasks);

      printf("Initializing arrays...\n");
      
      for (i=0; i<ROWS_A; i++)
         for (j=0; j<COLS_A; j++)
            a[i][j]= i+j;
      
      for (i=0; i<COLS_A; i++)
         for (j=0; j<COLS_B; j++)
            b[i][j]= i*j;
      
      chunksize                                                     = ROWS_A / numworkers;
      leftover                                                      = ROWS_A % numworkers;
      
      offset                                                        = 0;
      mtype                                                         = FROM_MASTER;
      
      for (dest=1; dest<=numworkers; dest++)
      {
         rows = (dest <= leftover) ? chunksize+1 : chunksize;   	

         printf("Sending %d rows to task %d offset=%d\n",rows,dest,offset);
         
         MPI_Send(&offset,       1,             MPI_INT,    dest, mtype, MPI_COMM_WORLD);
         
         MPI_Send(&rows,         1,             MPI_INT,    dest, mtype, MPI_COMM_WORLD);

         MPI_Send(&a[offset][0], rows*COLS_A,   MPI_DOUBLE, dest, mtype, MPI_COMM_WORLD);
         
         MPI_Send(&b,            COLS_A*COLS_B, MPI_DOUBLE, dest, mtype, MPI_COMM_WORLD);

         offset = offset + rows;
      }

      mtype = FROM_WORKER;

      for (i=1; i<=numworkers; i++)
      {
         source = i;

         MPI_Recv(&offset,       1,           MPI_INT,    source, mtype, MPI_COMM_WORLD, &status);

         MPI_Recv(&rows,         1,           MPI_INT,    source, mtype, MPI_COMM_WORLD, &status);
         
         MPI_Recv(&c[offset][0], rows*COLS_B, MPI_DOUBLE, source, mtype, MPI_COMM_WORLD, &status);

         printf("Received results from task %d\n",source);
      }

      printf("******************************************************\n");
      printf("Result Matrix:\n");

      for (i=0; i<ROWS_A; i++)
      {
         printf("\n"); 

         for (j=0; j<COLS_B; j++) 
         {
            printf("%6.2f   ", c[i][j]);
         }            
      }

      printf("\n******************************************************\n");
      printf ("Done.\n");
   }

   if (taskid > MASTER)
   {
      mtype = FROM_MASTER;

      MPI_Recv(&offset, 1,             MPI_INT,    MASTER, mtype, MPI_COMM_WORLD, &status);

      MPI_Recv(&rows,   1,             MPI_INT,    MASTER, mtype, MPI_COMM_WORLD, &status);
      
      MPI_Recv(&a,      rows*COLS_A,   MPI_DOUBLE, MASTER, mtype, MPI_COMM_WORLD, &status);
      
      MPI_Recv(&b,      COLS_A*COLS_B, MPI_DOUBLE, MASTER, mtype, MPI_COMM_WORLD, &status);

      for (k=0; k<COLS_B; k++)
      {
         for (i=0; i<rows; i++)
         {
            c[i][k] = 0.0;

            for (j=0; j<COLS_A; j++)
            {
               c[i][k] = c[i][k] + a[i][j] * b[j][k];
            }               
         }
      }

      mtype = FROM_WORKER;

      MPI_Send(&offset, 1,           MPI_INT,    MASTER, mtype, MPI_COMM_WORLD);

      MPI_Send(&rows,   1,           MPI_INT,    MASTER, mtype, MPI_COMM_WORLD);
      
      MPI_Send(&c,      rows*COLS_B, MPI_DOUBLE, MASTER, mtype, MPI_COMM_WORLD);
   }

   MPI_Finalize();
}
