/******************************************************************************
* FILE: mpi_helloBsend.c
* DESCRIPTION:
*   MPI tutorial example code: Simple hello world program that uses blocking
*   send/receive routines.
* AUTHOR: Blaise Barney
* LAST REVISED: 06/08/15
******************************************************************************/
#include "mpi.h"
#include <stdio.h>
#include <stdlib.h>

#define  MASTER		0

int main (int argc, char *argv[])
{

int  numtasks, taskid, len, partner, message; // taskid = rank

int custom_message;

char hostname[MPI_MAX_PROCESSOR_NAME];

MPI_Status status;

MPI_Init(&argc, &argv);

MPI_Comm_rank(MPI_COMM_WORLD, &taskid);

MPI_Comm_size(MPI_COMM_WORLD, &numtasks);

if (numtasks % 2 != 0) 
{
   if (taskid == MASTER) 
      printf("Quitting. Need an even number of tasks: numtasks=%d\n", numtasks);

   return 0;
} 

if (taskid == MASTER) 
   printf("MASTER: Number of MPI tasks is: %d\n\n",numtasks);

MPI_Get_processor_name(hostname, &len);

printf ("Hello from task %d on %s!\n", taskid, hostname);

if (taskid < numtasks/2) 
{
   partner = numtasks/2 + taskid;

   custom_message = 24;

   MPI_Send(&custom_message, 1, MPI_INT, partner, 1, MPI_COMM_WORLD);

   // MPI_Recv(&message, 1, MPI_INT, partner, 1, MPI_COMM_WORLD, &status);
}
else if (taskid >= numtasks/2) 
{
   partner = taskid - numtasks/2;

   custom_message = 25;

   MPI_Send(&custom_message, 1, MPI_INT, partner, 1, MPI_COMM_WORLD);

   MPI_Recv(&message, 1, MPI_INT, partner, 1, MPI_COMM_WORLD, &status);   
}

printf("Task %d is partner with %d\n\n",taskid, message);

MPI_Finalize();

}

