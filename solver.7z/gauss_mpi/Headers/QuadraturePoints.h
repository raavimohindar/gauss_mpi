// QuadraturePoints.h
// Created on: May 17, 2017
// Author: Raavi M. Mohindar Rao


#include "Alphabet.h"

namespace Solver
{
    class QuadraturePoints
    {
    public:
        static Eigen::Matrix<Eigen::Vector3d, 7, 1>                 Compute(NumericalIntegration numerical_integration, Eigen::Matrix<Eigen::Vector3d, 3, 1> vertices)
        {
            Eigen::Matrix<Eigen::Vector3d, 7, 1> r;

            for ( int i=0; i<7; i++ )
            {
                r[i] = numerical_integration.get_ell_1()[i]*vertices[0] +
                       numerical_integration.get_ell_2()[i]*vertices[1] +
                       numerical_integration.get_ell_3()[i]*vertices[2];
            }

            return r;
        }

    private:
        QuadraturePoints();

        QuadraturePoints(const QuadraturePoints&) = delete;

        QuadraturePoints& operator= (const QuadraturePoints&) = delete;
    };

}


