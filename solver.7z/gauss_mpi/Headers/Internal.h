namespace Solver
{
    class Internal
    {
    public:

        static std::complex<double>                                 exp_j(double k, double r)
        {
            std::complex<double> complexj                           (0.0, 1.0);

            std::complex<double> exponential_j                      = cos(k*r) + (complexj*sin(k*r));

            return exponential_j;
        }

        static std::complex<double>                                 exp_mj(double k, double r)
        {
            std::complex<double> complexj                           (0.0, 1.0);

            std::complex<double> exponential_mj                     = cos(k*r) - (complexj*sin(k*r));

            return exponential_mj;
        }

        static double 												pow2(double x)
        {
           return x*x;
        }

        static double                                               magnitude(std::complex<double> Z)
        {
            return sqrt(pow(Z.real(), 2) + pow(Z.imag(),2));
        }

        static Eigen::Vector3d                                      unit_r_spherical(double theta, double phi)
        {
            Eigen::Vector3d rhat ( sin ( theta ) *cos ( phi ), sin ( theta ) *sin ( phi ), cos ( theta ) );

            return rhat;
        }

        static Eigen::Vector3d                                      unit_theta_spherical(double theta, double phi)
        {
            Eigen::Vector3d thetahat ( cos ( theta ) *cos ( phi ), cos ( theta ) *sin ( phi ), -1.0*sin ( theta ) );

            return thetahat;
        }

        static Eigen::Vector3d                                      unit_phi_spherical(double phi)
        {
            Eigen::Vector3d phihat ( -1.0*sin ( phi ), cos ( phi ),  0.0 );

            return phihat;
        }

        static Eigen::Vector3d                                      unit_rho_cylindrical(double phi)
        {
            Eigen::Vector3d r_hat	( cos ( phi ), sin ( phi ), 0.0 );
            return r_hat;
        }

        static Eigen::Vector3d                                      unit_phi_cylindrical(double phi)
        {
            Eigen::Vector3d phi_hat	( -1.0*sin ( phi ), cos ( phi ), 0.0 );
            return phi_hat;
        }

        static double                                               msl_sf_bessel_Jn_prime( int m, double arg )
        {
            double derivative                                       = ( (m / arg) *  gsl_sf_bessel_Jn ( m, arg ) ) - gsl_sf_bessel_Jn ( m+1, arg ) ;
            return derivative;
        }

        template<class ReturnType, typename T, typename U>
        static ReturnType                                           Dot(T x, U y)
        {
            ReturnType dotProd                                      = ( ( x[0]*y[0] ) + ( x[1]*y[1] ) + ( x[2]*y[2] ) );
            return dotProd;
        }

        template<class ReturnType, typename T, typename U>
        static void                                                 TestDot(T x , U y)
        {
            ReturnType dotProd                                      = ( ( x[0]*y[0] ) + ( x[1]*y[1] ) + ( x[2]*y[2] ) );
            ReturnType eigendot                                     = x.dot(y);

            std::cout << std::endl;
            std::cout<< "Dot<T> "<<dotProd<<std::endl;
            std::cout<< "eigen  "<<eigendot<<std::endl;
        }

        template<class ReturnType, typename T, typename U>
        static ReturnType                                           Cross(T x , U y)
        {
            ReturnType crossProd	( ( ( x[1]*y[2] ) - ( x[2]*y[1] ) ), -1.0* ( ( x[0]*y[2] ) - ( x[2]*y[0] ) ), ( ( x[0]*y[1] ) - ( x[1]*y[0] ) ) );
            return crossProd;
        }

        template<class ReturnType, typename T, typename U>
        static void                                                 TestCross(T x , U y)
        {
            ReturnType crossProdt	( ( ( x[1]*y[2] ) - ( x[2]*y[1] ) ), -1.0 * ( ( x[0]*y[2] ) - ( x[2]*y[0] ) ), ( ( x[0]*y[1] ) - ( x[1]*y[0] ) ) );
            ReturnType eigenCross                                   = x.cross(y);

            std::cout << std::endl;
            std::cout<< "Cross<T> "<<crossProdt[0]<<"\t"<<crossProdt[1]<<"\t"<<crossProdt[2]<<std::endl;
            std::cout<< "eigen    "<<eigenCross[0]<<"\t"<<eigenCross[1]<<"\t"<<eigenCross[2]<<std::endl;
        }

        template<typename T>
        static double                                               ConditionNumberSVD (T x)
        {
            Eigen::JacobiSVD<T>                                     svd(x);

            double conditionNumberr                                 = svd.singularValues()(0) / svd.singularValues()(svd.singularValues().size()-1);

            return conditionNumberr;
        }

    private:
        Internal();

        Internal(const Internal&) = delete;

        Internal& operator= (const Internal&) = delete;
    };
}