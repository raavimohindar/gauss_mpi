namespace Solver
{
    class MOM
    {
    public:

      MOM();

      void                                                          Simulate(int, char* []);

      virtual ~MOM();

    private:

    	long int speedofLight                                         = 299792458;
	    double pi                                                     = 3.141592653589793238;       


    };
}