namespace Solver
{

class MeshData
{
public:
  MeshData(std::string&);
  
  int																                                get_triangle_count();
  
  Eigen::Matrix<Eigen::Vector3d, Eigen::Dynamic, 1>                 get_nodes();
  Eigen::Matrix<Eigen::Vector3i, Eigen::Dynamic, 1>                 getElements();
  Eigen::Matrix<Eigen::Vector3d, 3, 1>                              get_vertices(int);

  virtual  ~MeshData ();

private:
  std::string                                                       filepath;

  int nodecount 													                          = 0;
  int nodeindex 													                          = 0;
  Eigen::Matrix<Eigen::Vector3d, Eigen::Dynamic, 1>                 node_array;

  int element_count 													                      = 0;
  int elementindex 													                        = 0;
  Eigen::Matrix<Eigen::Vector3i, Eigen::Dynamic, 1>                 element_array;

  void 																                              ReadMeshFile();
  void                                                              ReadNodes(std::string);
  void                                                              ReadElements(std::string);
};

};

