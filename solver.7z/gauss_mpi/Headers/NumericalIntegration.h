namespace Solver
{
    class NumericalIntegration
    {
	public:
        NumericalIntegration();

        Eigen::VectorXd                                             get_ell_1();
        Eigen::VectorXd                                             get_ell_2();
        Eigen::VectorXd                                             get_ell_3();
        Eigen::VectorXd                                             get_w_ell();

        virtual ~NumericalIntegration();

	private:
          Eigen::VectorXd                                           l1;
          Eigen::VectorXd                                           l2;
          Eigen::VectorXd                                           l3;
          Eigen::VectorXd                                           wl;

          void                                                      Compute();
    };
}