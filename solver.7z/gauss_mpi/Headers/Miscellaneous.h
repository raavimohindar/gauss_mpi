namespace Solver
{
	class Miscellaneous
	{
	public:
        Miscellaneous(NumericalIntegration&,
                      MeshData&);
		
		void 														Gausslaw();

		virtual ~Miscellaneous();

	private:
        NumericalIntegration                                        numerical_integration;
        MeshData													mesh_data;

	};
}
