#ifndef __ALPHABET_H__
#define __ALPHABET_H__

#include <algorithm>
#include <cfloat>
#include <climits>
#include <complex>
#include <fstream>
#include <iostream>
#include <iomanip>
#include <math.h>
#include <regex>
#include <set>
#include <string>
#include <tuple>
#include <utility>

#include <eigen3/Eigen/Dense>

#include <gsl/gsl_sf_legendre.h>
#include <gsl/gsl_sf_bessel.h>
#include <gsl/gsl_integration.h>
#include <gsl/gsl_test.h>

#include <openmpi/mpi.h>

#ifndef __INTERNAL_H__
#define __INTERNAL_H__
#include "Internal.h"
#endif 

#ifndef __NUMERICALINTEGRATION_H__
#define __NUMERICALINTEGRATION_H__
#include "NumericalIntegration.h"
#endif 

#ifndef __QUADRATUREPOINTS_H__
#define __QUADRATUREPOINTS_H__
#include "QuadraturePoints.h"
#endif 

#ifndef __MESHDATA_H__
#define __MESHDATA_H__
#include "MeshData.h"
#endif

#ifndef __MOM_H__
#define __MOM_H__
#include "MOM.h"
#endif

#ifndef __MISCELLANEOUS_H__
#define __MISCELLANEOUS_H__
#include "Miscellaneous.h"
#endif

#endif
