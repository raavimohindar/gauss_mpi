#include "../Headers/Alphabet.h"

namespace Solver
{

Miscellaneous::Miscellaneous(NumericalIntegration& numerical_integration ,
                             MeshData& mesh_data) :
                             numerical_integration(numerical_integration),
                             mesh_data(mesh_data)
{ }

void Miscellaneous::Gausslaw()
{
	double integralSumGauss											= 0.0;
	double q 														= 1.0;
	double pi 														= atan(1.0) * 4.0;

    Eigen::VectorXd wl												= numerical_integration.get_w_ell();

	// Eigen::Vector3d 												r(5.0e-2, 2.5e-3, -7.5e-2);

	Eigen::Vector3d 												r(0.0, -0.1, 0.3);

	int trianglecout 												= mesh_data.get_triangle_count();

	for(int i = 0; i<trianglecout; i++)
	{
		Eigen::Matrix<Eigen::Vector3d, 3, 1> vertices				= mesh_data.get_vertices(i);
        
		Eigen::Matrix<Eigen::Vector3d, 7, 1> rprime 				= QuadraturePoints::Compute(numerical_integration, vertices);

		Eigen::Vector3d normalvector 								= (vertices(1) - vertices(0)).cross(vertices(2) - vertices(0));

		for (int j = 0; j < 7; j++)
		{
			Eigen::Vector3d distance 								= rprime(j) - r;

			Eigen::Vector3d R_hat    								= distance / distance.norm();
			
			Eigen::Vector3d D_r        								= R_hat * (q / (4.0 * pi * pow(distance.norm(), 2)) );
			
			integralSumGauss 										+= (wl[j] * D_r.dot(normalvector));
		}
	}

	std::cout <<"Gauss law "<<integralSumGauss<<std::endl;
}

Miscellaneous::~Miscellaneous()
{

}

}
