#include "../Headers/Alphabet.h"

namespace Solver
{

NumericalIntegration::NumericalIntegration()
{
    Compute();
}

void NumericalIntegration::Compute()
{
    int j;

    double a;
    double b;
    double c;
    double r, s;

    Eigen::Vector3d vert_x                                          (0.0, 1.0, 0.0);
    Eigen::Vector3d vert_y                                          (0.0, 0.0, 1.0);
    Eigen::Vector3d vert_z                                          (0.0, 0.0, 0.0);

    Eigen::Vector3d n_vec                                           = Internal::Cross<Eigen::Vector3d>( (vert_z - vert_y), (vert_z - vert_x) );

    double area                                                     = n_vec.norm() / 2.0;

    double centroid_x                                               = (vert_x[0] + vert_x[1] + vert_x[2]) / 3.0;
    double centroid_y                                               = (vert_y[0] + vert_y[1] + vert_y[2]) / 3.0;

    a 																= area * ( 155.0 - sqrt ( 15.0 ) ) / 1200.0;
    b 																= area * ( 155.0 + sqrt ( 15.0 ) ) / 1200.0;

    c 																= (9.0 * area) / 40.0;

    r 																= ( 1 + sqrt ( 15.0 ) ) / 7.0;
    s 																= ( 1 - sqrt ( 15.0 ) ) / 7.0;

    j 																= 0;

    l1 																= Eigen::VectorXd::Zero ( 7 );
    l2 																= Eigen::VectorXd::Zero ( 7 );
    l3 																= Eigen::VectorXd::Zero ( 7 );
    wl 																= Eigen::VectorXd::Zero ( 7 );

    for ( int i=0; i<3; i++ )
    {
        l1[j] 														= ( r * vert_x[i] ) + ( ( 1 - r ) * centroid_x );
        l2[j] 														= ( r * vert_y[i] ) + ( ( 1 - r ) * centroid_y );
        l3[j] 														= 1 - l1[j] - l2[j];
        wl[j] 														= a;

        j 															= j + 1;

        l1[j] 														= ( s * vert_x[i] ) + ( ( 1 - s ) * centroid_x );
        l2[j] 														= ( s * vert_y[i] ) + ( ( 1 - s ) * centroid_y );
        l3[j] 														= 1 - l1[j] - l2[j];
        wl[j] 														= b;

        j 															= j + 1;
    }

    l1[6] 															= centroid_x;
    l2[6] 															= centroid_y;
    l3[6] 															= 1 - l1[6] - l2[6];
    wl[6] 															= c;
}

Eigen::VectorXd NumericalIntegration::get_ell_1()
{
    return l1;
}

Eigen::VectorXd NumericalIntegration::get_ell_2()
{
    return l2;
}

Eigen::VectorXd NumericalIntegration::get_ell_3()
{
    return l3;
}

Eigen::VectorXd NumericalIntegration::get_w_ell()
{
    return wl;
}

NumericalIntegration::~NumericalIntegration() {
    
}


}

// kate: indent-mode cstyle; indent-width 4; replace-tabs on; 
