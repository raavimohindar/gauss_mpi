#include "../Headers/Alphabet.h"

namespace Solver
{

MeshData::MeshData(std::string& filepath) : 
				   filepath(filepath)
{
	nodeindex														= -1;
	nodecount														= 0;
	element_count													= 0;
	elementindex													= -1;

	ReadMeshFile();
}

void MeshData::ReadMeshFile()
{
	std::string data;

	bool readnodes 													= false;
	bool readelements 												= false;

	std::ifstream inputStream (filepath.c_str ());

	while (std::getline(inputStream, data))
	{
		if (data == "$Nodes") 		readnodes 						= true;
		if (data == "$EndNodes") 	readnodes 						= false;

		if (readnodes) ReadNodes(data);

		if (data == "$Elements") 	readelements 					= true;
		if (data == "$EndElements")	readelements 					= false;

		if (readelements) ReadElements(data);
	}

	inputStream.close ();
}

void MeshData::ReadNodes(std::string nodeString)
{
	if (nodeString != "$Nodes")
	{
		size_t previous 											= 0;
		size_t next 												= 0;
		int index 													= 0;
		Eigen::Vector3d nodeValues;

		if (nodecount == 0)
		{
			nodecount 												= std::stoi(nodeString.substr(previous));
			node_array												= Eigen::Matrix<Eigen::Vector3d, Eigen::Dynamic, 1>(nodecount);
		}

		while ((next = nodeString.find(" ", previous)) != std::string::npos)
		{
			if(index == 0) nodeindex 								= std::stod(nodeString.substr(previous, next-previous))-1;
			if(index  > 0) nodeValues[index-1] 						= std::stod(nodeString.substr(previous, next-previous));
			previous 												= next+1;
			index++;
		}

		if(nodeindex > -1)
		{
			nodeValues[index-1] 									= std::stod(nodeString.substr(previous));
			node_array[nodeindex] 									= nodeValues;
		}
	}
}

void MeshData::ReadElements(std::string elementString)
{
	if (elementString != "$Elements")
	{
		std::string s 												= elementString;
		size_t last 												= 0;
		size_t next 												= 0;
		int index 													= 0;
		Eigen::Vector3i element_values;

		if (element_count == 0)
		{
			element_count 											= std::stoi(s.substr(last));
			element_array											= Eigen::Matrix<Eigen::Vector3i, Eigen::Dynamic, 1>(element_count);
		}

		while ((next = s.find(" ", last)) != std::string::npos)
		{
			if(index == 0) elementindex								= std::stoi(s.substr(last, next-last))-1;
			if(index > 4) element_values[index-5] 					= std::stoi(s.substr(last, next-last))-1;
			last 													= next+1;
			index++;
		}

		if(elementindex > -1)
		{
			element_values[index-5] 								= std::stoi(s.substr(last))-1;
			element_array[elementindex] 							= element_values;
		}
	}
}

Eigen::Matrix<Eigen::Vector3d, 3, 1> MeshData::get_vertices(int triangle)
{
	int v1 															= element_array[triangle][0];
	int v2															= element_array[triangle][1];
	int v3															= element_array[triangle][2];

	Eigen::Matrix<Eigen::Vector3d, 3 ,1> vertices(node_array[v1], node_array[v2], node_array[v3]);
	return vertices;
}

int MeshData::get_triangle_count() 											{ return element_count; }

Eigen::Matrix<Eigen::Vector3d, Eigen::Dynamic, 1> MeshData::get_nodes() 	{ return node_array; }

Eigen::Matrix<Eigen::Vector3i, Eigen::Dynamic, 1> MeshData::getElements()	{ return element_array; }

MeshData::~MeshData()
{

}

};
