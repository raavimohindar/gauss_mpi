#include "../Headers/Alphabet.h"

int main(int argc, char* argv[])
{
    if(argc < 1)
    {
        std::cerr << "Usage: " << argv[0] << std::endl;
    }

    Solver::MOM                                            mom;

    mom.Simulate();
    
	return 0;
}

namespace Solver
{

MOM::MOM()
{  }

void MOM::Simulate()
{    
    std::cout << std::fixed;

    std::string current_path = __FILE__;

    auto truncated_path = [](auto p) -> std::string
    { 
        std::smatch m;         
        return std::regex_search (p, m, std::regex(".+?(?=Sources)")) ? m.str(0) : std::string();               
    }(current_path);

    if (truncated_path.empty())
    {
        std::cerr <<"Please run the executable from build directory..."<<std::endl;
        return;
    } 

    std::string mesh_file                                           = truncated_path+std::string("Mesh/box.msh");
    std::string output_file                                         = truncated_path+std::string("Gnuplot/output_directivity_mom.dat");

    Solver::NumericalIntegration                                    numerical_integration;
       
    Solver::MeshData                                                mesh_data(mesh_file);

    std::cout <<"Triangle count: "<<mesh_data.get_triangle_count()<<std::endl;
    
    Miscellaneous gauss_mpi(numerical_integration, mesh_data);

    gauss_mpi.Gausslaw();
}

MOM::~MOM() { }

}