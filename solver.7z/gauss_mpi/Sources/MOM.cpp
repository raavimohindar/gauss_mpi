#include "../Headers/Alphabet.h"

int main(int argc, char* argv[])
{
    if(argc < 1)
    {
        std::cerr << "Usage: " << argv[0] << std::endl;
    }

    Solver::MOM                                            mom;

    mom.Simulate(argc, argv);
    
	return 0;
}

namespace Solver
{

MOM::MOM()
{  }

void MOM::Simulate(int argc, char* argv[])
{    
    std::cout << std::fixed;

    std::string current_path = __FILE__;

    auto truncated_path = [](auto p) -> std::string
    { 
        std::smatch m;         
        return std::regex_search (p, m, std::regex(".+?(?=Sources)")) ? m.str(0) : std::string();               
    }(current_path);

    if (truncated_path.empty())
    {
        std::cerr <<"Please run the executable from build directory..."<<std::endl;
        return;
    } 

    std::string mesh_file                                           = truncated_path+std::string("Mesh/fuselage.msh");
    std::string output_file                                         = truncated_path+std::string("Gnuplot/output_directivity_mom.dat");

    Solver::NumericalIntegration                                    numerical_integration;       
    Solver::MeshData                                                mesh_data(mesh_file);

    std::cout <<"Triangle count: "<<mesh_data.get_triangle_count()<<std::endl;

    int num_tasks;
    int task_id;
    int len;

    char hostname[MPI_MAX_PROCESSOR_NAME];

    MPI_Init(&argc, &argv);

    MPI_Comm_size(MPI_COMM_WORLD, &num_tasks);
    MPI_Comm_rank(MPI_COMM_WORLD, &task_id);

    MPI_Get_processor_name(hostname, &len);

    std::cout << "num_tasks "<<num_tasks<<std::endl;
    std::cout << "task_id   "<<task_id  <<std::endl;
    std::cout << "hostname   "<<hostname  <<std::endl;
    
    Miscellaneous gauss_mpi(numerical_integration, mesh_data);

    gauss_mpi.Gausslaw();

    MPI_Finalize();
}

MOM::~MOM() { }

}